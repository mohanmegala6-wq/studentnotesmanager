// Student Study Materials
// Actual file data is stored in IndexedDB in this browser.

const DB_NAME = "StudentStudyMaterialsDB";
const DB_VERSION = 1;
const STORE_NAME = "materials";
const MAX_FILE_SIZE = 25 * 1024 * 1024; // 25 MB per file

const uploadForm = document.getElementById("uploadForm");
const subjectInput = document.getElementById("subjectInput");
const fileInput = document.getElementById("fileInput");
const uploadButton = document.getElementById("uploadButton");
const uploadStatus = document.getElementById("uploadStatus");
const searchInput = document.getElementById("searchInput");
const categoryFilter = document.getElementById("categoryFilter");
const subjectSuggestions = document.getElementById("subjectSuggestions");
const materialsList = document.getElementById("materialsList");
const summary = document.getElementById("summary");
const backupButton = document.getElementById("backupButton");
const restoreInput = document.getElementById("restoreInput");
const previewDialog = document.getElementById("previewDialog");
const previewTitle = document.getElementById("previewTitle");
const previewBody = document.getElementById("previewBody");

let database;
let materials = [];
let currentPreviewUrl = null;

function openDatabase() {
  return new Promise((resolve, reject) => {
    if (!("indexedDB" in window)) {
      reject(new Error("Your browser does not support IndexedDB."));
      return;
    }

    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: "id", autoIncrement: true });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("Could not open browser storage."));
  });
}

function saveMaterial(record) {
  return new Promise((resolve, reject) => {
    const tx = database.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).add(record);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error || new Error("Could not save material."));
    tx.onabort = () => reject(tx.error || new Error("Saving was cancelled."));
  });
}

function readMaterials() {
  return new Promise((resolve, reject) => {
    const request = database.transaction(STORE_NAME, "readonly")
      .objectStore(STORE_NAME).getAll();
    request.onsuccess = () => resolve(request.result || []);
    request.onerror = () => reject(request.error || new Error("Could not load materials."));
  });
}

function deleteMaterial(id) {
  return new Promise((resolve, reject) => {
    const tx = database.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).delete(id);
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error || new Error("Could not delete material."));
  });
}

function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function formatDate(timestamp) {
  return new Date(timestamp).toLocaleString();
}

function safeText(tag, text, className) {
  const element = document.createElement(tag);
  element.textContent = text;
  if (className) element.className = className;
  return element;
}

function updateCategories() {
  const current = categoryFilter.value;
  const categories = [...new Set(materials.map(m => m.subject).filter(Boolean))]
    .sort((a, b) => a.localeCompare(b));

  categoryFilter.replaceChildren(new Option("All subjects", ""));
  subjectSuggestions.replaceChildren();

  categories.forEach(subject => {
    categoryFilter.add(new Option(subject, subject));
    subjectSuggestions.appendChild(new Option(subject, subject));
  });

  categoryFilter.value = categories.includes(current) ? current : "";
}

function renderMaterials() {
  updateCategories();
  materialsList.replaceChildren();

  const search = searchInput.value.trim().toLowerCase();
  const category = categoryFilter.value;
  const filtered = materials
    .filter(item => !category || item.subject === category)
    .filter(item => !search ||
      item.name.toLowerCase().includes(search) ||
      item.subject.toLowerCase().includes(search))
    .sort((a, b) => b.createdAt - a.createdAt);

  summary.textContent = `${materials.length} material${materials.length === 1 ? "" : "s"} saved · Showing ${filtered.length}`;

  if (!filtered.length) {
    const empty = safeText("div",
      materials.length ? "No materials match your search or category." : "No study materials yet. Choose a subject and upload your first file.",
      "empty-state");
    materialsList.appendChild(empty);
    return;
  }

  filtered.forEach(item => {
    const card = document.createElement("article");
    card.className = "material-card";

    card.appendChild(safeText("span", item.subject, "subject-tag"));
    card.appendChild(safeText("h3", item.name));
    card.appendChild(safeText("p",
      `${formatBytes(item.size)} · Uploaded ${formatDate(item.createdAt)}`,
      "file-meta"));

    const actions = document.createElement("div");
    actions.className = "card-actions";

    const previewButton = document.createElement("button");
    previewButton.type = "button";
    previewButton.textContent = "Preview";
    previewButton.addEventListener("click", () => previewMaterial(item));

    const downloadButton = document.createElement("button");
    downloadButton.type = "button";
    downloadButton.className = "secondary";
    downloadButton.textContent = "Download";
    downloadButton.addEventListener("click", () => downloadMaterial(item));

    const deleteButton = document.createElement("button");
    deleteButton.type = "button";
    deleteButton.className = "danger";
    deleteButton.textContent = "Delete";
    deleteButton.addEventListener("click", async () => {
      if (!confirm(`Delete "${item.name}" from this browser?`)) return;
      try {
        await deleteMaterial(item.id);
        await refreshMaterials();
        uploadStatus.textContent = `Deleted ${item.name}.`;
      } catch (error) {
        alert("Could not delete this material: " + error.message);
      }
    });

    actions.append(previewButton, downloadButton, deleteButton);
    card.appendChild(actions);
    materialsList.appendChild(card);
  });
}

async function refreshMaterials() {
  materials = await readMaterials();
  renderMaterials();
}

function makeObjectUrl(item) {
  return URL.createObjectURL(item.file);
}

function downloadMaterial(item) {
  const url = makeObjectUrl(item);
  const link = document.createElement("a");
  link.href = url;
  link.download = item.name;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}

function previewMaterial(item) {
  if (currentPreviewUrl) URL.revokeObjectURL(currentPreviewUrl);
  currentPreviewUrl = makeObjectUrl(item);
  previewTitle.textContent = item.name;
  previewBody.replaceChildren();

  const type = (item.type || "").toLowerCase();
  const ext = item.name.split(".").pop().toLowerCase();

  if (type.startsWith("image/") || ["jpg", "jpeg", "png", "gif", "webp"].includes(ext)) {
    const img = document.createElement("img");
    img.src = currentPreviewUrl;
    img.alt = item.name;
    previewBody.appendChild(img);
  } else if (type === "application/pdf" || ext === "pdf") {
    const frame = document.createElement("iframe");
    frame.src = currentPreviewUrl;
    frame.title = "PDF preview";
    previewBody.appendChild(frame);
  } else if (["txt", "csv"].includes(ext) || type.startsWith("text/")) {
    const reader = new FileReader();
    reader.onload = () => {
      previewBody.replaceChildren(safeText("pre", String(reader.result || "")));
    };
    reader.onerror = () => {
      previewBody.appendChild(safeText("p", "Could not preview this text file. Please download it."));
    };
    reader.readAsText(item.file);
  } else {
    previewBody.appendChild(safeText("p",
      "Your browser cannot preview this file type here. Use Download to open it in the appropriate app."));
    const downloadButton = document.createElement("button");
    downloadButton.textContent = "Download file";
    downloadButton.addEventListener("click", () => downloadMaterial(item));
    previewBody.appendChild(downloadButton);
  }

  if (typeof previewDialog.showModal === "function") previewDialog.showModal();
  else window.open(currentPreviewUrl, "_blank", "noopener");
}

document.getElementById("closePreview").addEventListener("click", () => {
  previewDialog.close();
});
previewDialog.addEventListener("close", () => {
  if (currentPreviewUrl) URL.revokeObjectURL(currentPreviewUrl);
  currentPreviewUrl = null;
});

uploadForm.addEventListener("submit", async event => {
  event.preventDefault();
  const subject = subjectInput.value.trim();
  const file = fileInput.files[0];

  if (!subject || !file) {
    uploadStatus.textContent = "Please enter a subject and choose a file.";
    return;
  }
  if (file.size > MAX_FILE_SIZE) {
    uploadStatus.textContent = "This file is larger than 25 MB. Please choose a smaller file.";
    return;
  }

  uploadButton.disabled = true;
  uploadStatus.textContent = "Saving material in this browser…";
  try {
    await saveMaterial({
      subject,
      name: file.name,
      type: file.type || "application/octet-stream",
      size: file.size,
      createdAt: Date.now(),
      file
    });
    uploadForm.reset();
    uploadStatus.textContent = "Material saved successfully!";
    await refreshMaterials();
  } catch (error) {
    uploadStatus.textContent = "Could not save this file. Browser storage may be full. Keep your original file as a backup. " + error.message;
  } finally {
    uploadButton.disabled = false;
  }
});

searchInput.addEventListener("input", renderMaterials);
categoryFilter.addEventListener("change", renderMaterials);

function blobToBase64(blob) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result);
      resolve(result.slice(result.indexOf(",") + 1));
    };
    reader.onerror = () => reject(reader.error || new Error("Could not read a file for backup."));
    reader.readAsDataURL(blob);
  });
}

function base64ToBlob(base64, type) {
  const binary = atob(base64);
  const parts = [];
  const chunkSize = 1024;
  for (let i = 0; i < binary.length; i += chunkSize) {
    const slice = binary.slice(i, i + chunkSize);
    const bytes = new Uint8Array(slice.length);
    for (let j = 0; j < slice.length; j++) bytes[j] = slice.charCodeAt(j);
    parts.push(bytes);
  }
  return new Blob(parts, { type: type || "application/octet-stream" });
}

backupButton.addEventListener("click", async () => {
  backupButton.disabled = true;
  uploadStatus.textContent = "Preparing backup. Please wait…";
  try {
    const exportItems = [];
    for (const item of materials) {
      exportItems.push({
        subject: item.subject,
        name: item.name,
        type: item.type,
        size: item.size,
        createdAt: item.createdAt,
        dataBase64: await blobToBase64(item.file)
      });
    }

    const backup = {
      app: "Student Study Materials",
      version: 1,
      exportedAt: new Date().toISOString(),
      materials: exportItems
    };
    const blob = new Blob([JSON.stringify(backup)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `student-study-materials-backup-${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    uploadStatus.textContent = `Backup downloaded (${materials.length} material${materials.length === 1 ? "" : "s"}). Keep it somewhere safe.`;
  } catch (error) {
    uploadStatus.textContent = "Backup failed: " + error.message;
  } finally {
    backupButton.disabled = false;
  }
});

restoreInput.addEventListener("change", async () => {
  const backupFile = restoreInput.files[0];
  if (!backupFile) return;
  if (!confirm("Restore this backup? Its files will be added to your current materials.")) {
    restoreInput.value = "";
    return;
  }

  uploadStatus.textContent = "Restoring backup…";
  try {
    const backup = JSON.parse(await backupFile.text());
    if (!backup || backup.app !== "Student Study Materials" || !Array.isArray(backup.materials)) {
      throw new Error("This does not look like a backup created by this app.");
    }

    let restored = 0;
    for (const item of backup.materials) {
      if (!item.name || typeof item.dataBase64 !== "string") continue;
      const blob = base64ToBlob(item.dataBase64, item.type);
      await saveMaterial({
        subject: String(item.subject || "Uncategorized"),
        name: String(item.name),
        type: String(item.type || blob.type || "application/octet-stream"),
        size: blob.size,
        createdAt: Number(item.createdAt) || Date.now(),
        file: blob
      });
      restored++;
    }
    await refreshMaterials();
    uploadStatus.textContent = `Backup restored. Added ${restored} material${restored === 1 ? "" : "s"}.`;
  } catch (error) {
    uploadStatus.textContent = "Could not restore backup: " + error.message;
  } finally {
    restoreInput.value = "";
  }
});

(async function startApp() {
  try {
    database = await openDatabase();
    await refreshMaterials();
  } catch (error) {
    summary.textContent = "Browser storage could not start.";
    uploadStatus.textContent = "Storage error: " + error.message;
  }
})();
