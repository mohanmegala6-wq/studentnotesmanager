// STUDENT NOTES MANAGER
// Text notes use localStorage. Study files use IndexedDB.

const noteForm = document.getElementById("noteForm");
const subjectInput = document.getElementById("subject");
const topicInput = document.getElementById("topic");
const noteInput = document.getElementById("note");
const notesList = document.getElementById("notesList");
const searchInput = document.getElementById("search");
const noteCount = document.getElementById("noteCount");
const formTitle = document.getElementById("formTitle");
const saveButton = document.getElementById("saveButton");
const cancelButton = document.getElementById("cancelButton");

let notes = [];
try {
  notes = JSON.parse(localStorage.getItem("studentNotes")) || [];
  if (!Array.isArray(notes)) notes = [];
} catch {
  notes = [];
}
let editingId = null;

function saveNotes() {
  localStorage.setItem("studentNotes", JSON.stringify(notes));
}

function displayNotes() {
  notesList.replaceChildren();
  const searchText = searchInput.value.toLowerCase().trim();
  const filteredNotes = notes.filter(item =>
    (item.subject || "").toLowerCase().includes(searchText) ||
    (item.topic || "").toLowerCase().includes(searchText) ||
    (item.note || "").toLowerCase().includes(searchText)
  );

  noteCount.textContent = `Total notes: ${notes.length} | Showing: ${filteredNotes.length}`;
  if (filteredNotes.length === 0) {
    const message = document.createElement("p");
    message.className = "empty-message";
    message.textContent = notes.length === 0
      ? "No notes yet. Add your first note above!"
      : "No matching notes found.";
    notesList.appendChild(message);
    return;
  }

  filteredNotes.forEach(item => {
    const card = document.createElement("article");
    card.className = "note-card";
    const heading = document.createElement("h3");
    heading.textContent = item.subject;
    const topic = document.createElement("h4");
    topic.textContent = "Topic: " + item.topic;
    const content = document.createElement("p");
    content.textContent = item.note;
    const editButton = document.createElement("button");
    editButton.textContent = "Edit";
    editButton.addEventListener("click", () => editNote(item.id));
    const deleteButton = document.createElement("button");
    deleteButton.textContent = "Delete";
    deleteButton.className = "delete";
    deleteButton.addEventListener("click", () => deleteNote(item.id));
    const actions = document.createElement("div");
    actions.className = "button-row";
    actions.append(editButton, deleteButton);
    card.append(heading, topic, content, actions);
    notesList.appendChild(card);
  });
}

noteForm.addEventListener("submit", event => {
  event.preventDefault();
  const subject = subjectInput.value.trim();
  const topic = topicInput.value.trim();
  const note = noteInput.value.trim();
  if (!subject || !topic || !note) {
    alert("Please fill in all three fields.");
    return;
  }

  if (editingId !== null) {
    const item = notes.find(n => n.id === editingId);
    if (item) Object.assign(item, { subject, topic, note });
  } else {
    notes.push({
      id: Date.now().toString() + Math.random().toString(36).slice(2),
      subject, topic, note
    });
  }
  saveNotes();
  noteForm.reset();
  resetEditMode();
  displayNotes();
});

function editNote(id) {
  const item = notes.find(n => n.id === id);
  if (!item) return;
  editingId = id;
  subjectInput.value = item.subject;
  topicInput.value = item.topic;
  noteInput.value = item.note;
  formTitle.textContent = "Edit Your Note";
  saveButton.textContent = "Update Note";
  cancelButton.hidden = false;
  document.querySelector(".form-box").scrollIntoView({ behavior: "smooth" });
  subjectInput.focus();
}

function deleteNote(id) {
  if (!confirm("Are you sure you want to delete this note?")) return;
  notes = notes.filter(item => item.id !== id);
  if (editingId === id) {
    noteForm.reset();
    resetEditMode();
  }
  saveNotes();
  displayNotes();
}

function resetEditMode() {
  editingId = null;
  formTitle.textContent = "Add Your Note";
  saveButton.textContent = "Add Note";
  cancelButton.hidden = true;
}

cancelButton.addEventListener("click", () => {
  noteForm.reset();
  resetEditMode();
});
searchInput.addEventListener("input", displayNotes);

// IndexedDB stores the actual material file, not just its filename.
const DB_NAME = "StudentNotesManagerDB";
const DB_VERSION = 1;
const STORE_NAME = "materials";
let db;

function openDatabase() {
  return new Promise((resolve, reject) => {
    if (!("indexedDB" in window)) {
      reject(new Error("This browser does not support IndexedDB."));
      return;
    }
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(STORE_NAME)) {
        const store = database.createObjectStore(STORE_NAME, {
          keyPath: "id",
          autoIncrement: true
        });
        store.createIndex("createdAt", "createdAt");
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("Could not open browser storage."));
  });
}

function addMaterial(material) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, "readwrite");
    transaction.objectStore(STORE_NAME).add(material);
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error || new Error("Could not save the file."));
    transaction.onabort = () => reject(transaction.error || new Error("File saving was cancelled."));
  });
}

function getAllMaterials() {
  return new Promise((resolve, reject) => {
    const request = db.transaction(STORE_NAME, "readonly")
      .objectStore(STORE_NAME).getAll();
    request.onsuccess = () => resolve(request.result || []);
    request.onerror = () => reject(request.error || new Error("Could not read saved files."));
  });
}

function removeMaterial(id) {
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(STORE_NAME, "readwrite");
    transaction.objectStore(STORE_NAME).delete(id);
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error || new Error("Could not delete the file."));
  });
}

function formatBytes(bytes) {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / (1024 * 1024)).toFixed(1) + " MB";
}

function showMaterials(materials) {
  const materialsList = document.getElementById("materialsList");
  materialsList.replaceChildren();

  if (materials.length === 0) {
    const message = document.createElement("p");
    message.className = "empty-message";
    message.textContent = "No study materials uploaded yet.";
    materialsList.appendChild(message);
    return;
  }

  materials.sort((a, b) => b.createdAt - a.createdAt).forEach(material => {
    const card = document.createElement("article");
    card.className = "material-card";
    const heading = document.createElement("h3");
    heading.textContent = `${material.subject} — ${material.name}`;
    const detail = document.createElement("p");
    detail.className = "hint";
    detail.textContent = `${formatBytes(material.size)} · Saved in this browser`;
    const openLink = document.createElement("a");
    openLink.href = URL.createObjectURL(material.file);
    openLink.target = "_blank";
    openLink.rel = "noopener";
    openLink.textContent = "Open / Download";
    openLink.download = material.name;
    const deleteButton = document.createElement("button");
    deleteButton.className = "delete";
    deleteButton.textContent = "Delete Material";
    deleteButton.addEventListener("click", async () => {
      if (!confirm(`Delete "${material.name}" from this browser?`)) return;
      try {
        await removeMaterial(material.id);
        await displayMaterials();
      } catch (error) {
        alert("Could not delete the material: " + error.message);
      }
    });
    const actions = document.createElement("div");
    actions.className = "button-row";
    actions.append(openLink, deleteButton);
    card.append(heading, detail, actions);
    materialsList.appendChild(card);
  });
}

async function displayMaterials() {
  try {
    showMaterials(await getAllMaterials());
  } catch (error) {
    document.getElementById("materialsList").textContent =
      "Could not load saved materials: " + error.message;
  }
}

const materialForm = document.getElementById("materialForm");
const materialSubject = document.getElementById("materialSubject");
const materialFile = document.getElementById("materialFile");
const uploadStatus = document.getElementById("uploadStatus");
const uploadButton = document.getElementById("uploadButton");

materialForm.addEventListener("submit", async event => {
  event.preventDefault();
  const subject = materialSubject.value.trim();
  const file = materialFile.files[0];

  if (!subject || !file) {
    uploadStatus.textContent = "Please enter a subject and choose a file.";
    return;
  }

  // A modest per-file limit helps avoid browser storage failures.
  const maxSize = 25 * 1024 * 1024;
  if (file.size > maxSize) {
    uploadStatus.textContent = "This file is larger than 25 MB. Please choose a smaller file.";
    return;
  }

  uploadButton.disabled = true;
  uploadStatus.textContent = "Saving your material...";
  try {
    await addMaterial({
      subject,
      name: file.name,
      type: file.type || "application/octet-stream",
      size: file.size,
      createdAt: Date.now(),
      file
    });
    materialForm.reset();
    uploadStatus.textContent = "Material saved successfully in this browser!";
    await displayMaterials();
  } catch (error) {
    uploadStatus.textContent =
      "Could not save the file. Browser storage may be full. Keep a backup of the original file. Details: " + error.message;
  } finally {
    uploadButton.disabled = false;
  }
});

(async function startApp() {
  displayNotes();
  try {
    db = await openDatabase();
    await displayMaterials();
  } catch (error) {
    uploadStatus.textContent = "Browser storage could not start: " + error.message;
  }
})();
